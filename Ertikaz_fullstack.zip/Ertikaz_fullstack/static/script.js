document.getElementById('uploadForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    let fileInput = document.getElementById('contractFile');
    if(fileInput.files.length === 0) return;

    let formData = new FormData();
    formData.append('contract_file', fileInput.files[0]);

    // عرض رسالة التحميل وإخفاء النتائج القديمة
    document.getElementById('loading').style.display = 'block';
    document.getElementById('resultsSection').style.display = 'none';

    // إرسال الملف إلى الباك-إند (Flask) باستخدام Fetch API
    fetch('/analyze', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('loading').style.display = 'none';
        
        if(data.error) {
            alert(data.error);
            return;
        }

        // عرض النتائج القادمة من السيرفر وقاعدة البيانات في الواجهة
        document.getElementById('riskScore').innerText = data.risk_score + " / 100";
        document.getElementById('riskLevel').innerText = data.risk_level;
        document.getElementById('contractSummary').innerText = data.summary;
        document.getElementById('contractSuggestion').innerText = data.suggestion;
        document.getElementById('contractDraft').value = data.draft;

        // إظهار قسم النتائج بحركة سلسة
        document.getElementById('resultsSection').style.display = 'block';
    })
    .catch(error => {
        document.getElementById('loading').style.display = 'none';
        console.error('Error:', error);
    });
});

function copyDraft() {
    let copyText = document.getElementById('contractDraft');
    copyText.select();
    document.execCommand("copy");
    alert("تم نسخ مسودة الرسالة الجاهزة بنجاح! 📋");
}